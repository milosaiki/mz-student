<?php

/**
 * Provide a admin area view for the plugin
 *
 * This file is used to markup the admin-facing aspects of the plugin.
 *
 * @link       www.linkedin.com/in/milos-zivic-2586a174
 * @since      1.0.0
 *
 * @package    Mz_Fakultet
 * @subpackage Mz_Fakultet/admin/partials
 */
?>

<!-- This file should primarily consist of HTML with a little bit of PHP. -->
